package runner;

import controller.Control;

public class Run {
	public static void main(String[] args) {
		new Control();
	}
}
