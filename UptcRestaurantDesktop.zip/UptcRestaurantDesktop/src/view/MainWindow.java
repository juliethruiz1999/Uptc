package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class MainWindow extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private StartPanel startPanel;
	private DefaultTableModel studentModel;
	private AdministratorWindow administratorWindow;
	private StudentWindow studentWindow;
	private JTable studentTable;	


	private StudentTablePanel studentTablePanel;

	public MainWindow(ActionListener listener) {

		setLayout(new BorderLayout());
		setExtendedState(MAXIMIZED_BOTH);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("Restaurante Uptc");
		setIconImage(new ImageIcon(getClass().getResource("/img/logo.png")).getImage());
		setBackground(Color.WHITE);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0,0));
		init(listener);
		
		StartPanel startPanel = new StartPanel(listener);
		add(startPanel);
		
		AdminMenuBar adminMenuBar = new AdminMenuBar(listener);
		setJMenuBar(adminMenuBar);

		TopLogoPanel topLogoPanel = new TopLogoPanel(listener);
		add(topLogoPanel, BorderLayout.NORTH);

		AdministratorWindow administratorWindow = new AdministratorWindow(listener);
		add(administratorWindow);
		
		StudentWindow studentWindow = new StudentWindow(listener);
		add(studentWindow);
		// BookingToolBar bookingToolBar = new BookingToolBar();
		// add(bookingToolBar, BorderLayout.PAGE_START);

		JPanel kk = new JPanel();
		kk.setLayout(new FlowLayout());
		kk.setBackground(Color.WHITE);
		CenterPanel centerPanel = new CenterPanel();
		centerPanel.setBackground(Color.WHITE);
		// add(centerPanel, BorderLayout.CENTER);
		kk.add(centerPanel);

		// add(tablesNumberPanel, BorderLayout.CENTER);
		add(kk, BorderLayout.CENTER);
		JPanel jp = new JPanel();
		jp.setBackground(Color.PINK);
		// add(jp, BorderLayout.EAST);
		
		setVisible(true);
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}



	public DefaultTableModel getStudentModel() {
		return studentModel;
	}



	public void setStudentModel(DefaultTableModel studentModel) {
		this.studentModel = studentModel;
	}



	public JTable getStudentTable() {
		return studentTable;
	}

	private void init(ActionListener listener) {
		// Instance
		startPanel = new StartPanel(listener);
		
//		admin = new JPanelEntrar(listener,e);
	}
	
	public void setStudentTable(JTable studentTable) {
		this.studentTable = studentTable;
	}

	public AdministratorWindow getAdministratorWindow() {
		return administratorWindow;
	}

	public void setAdministratorWindow(AdministratorWindow administratorWindow) {
		this.administratorWindow = administratorWindow;
	}

	public StartPanel getStartPanel() {
		return startPanel;
	}

	public void setStartPanel(StartPanel startPanel) {
		this.startPanel = startPanel;
	}
	
	public void showAdministratorPanel() {
//		getContentPane().removeAll();
//		getContentPane().add(administratorWindow, BorderLayout.CENTER);
		administratorWindow.setVisible(true);
	}

//	public void showStudentPanel() {
//		getContentPane().removeAll();
//		getContentPane().add(studentWindow, BorderLayout.CENTER);
//		studentWindow.setVisible(true);
//	}
//
//	public void back() {
//		getContentPane().removeAll();
//		getContentPane().add(startPanel, BorderLayout.CENTER);
//		startPanel.setVisible(true);
//
//	}
//
//	
	public void showStartPanel() {
		getContentPane().removeAll();
		getContentPane().add(startPanel, BorderLayout.CENTER);
		startPanel.setVisible(true);
//		
//
	}

	public void update() {
		repaint();
		setVisible(true);
	}

	public StudentTablePanel getStudentTablePanel() {
		return studentTablePanel;
	}

	public void setStudentTablePanel(StudentTablePanel studentTablePanel) {
		this.studentTablePanel = studentTablePanel;
	}

	
	public void changePanelAdmin(){
		administratorWindow.setVisible(true);
		startPanel.setVisible(false);
		setVisible(true);
		repaint();
		revalidate();
	}
	
	public void changeStudentPanel(){
		studentWindow.setVisible(true);
		startPanel.setVisible(false);
		setVisible(true);
		revalidate();
	}
	
	public void changeStartPanel(){
		startPanel.setVisible(true);
		studentWindow.setVisible(false);
		setVisible(true);
		revalidate();
	}
	
	public StudentWindow getStudentWindow() {
		return studentWindow;
	}

	public void setStudentWindow(StudentWindow studentWindow) {
		this.studentWindow = studentWindow;
	}

}