package view;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

public class CenterPanel extends JPanel{

	private static final long serialVersionUID = 1L;

	public CenterPanel() {
		
	}
}
