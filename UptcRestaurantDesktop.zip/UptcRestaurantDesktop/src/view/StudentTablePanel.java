package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.util.ArrayList;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import model.Student;

public class StudentTablePanel extends JPanel{

	private static final long serialVersionUID = 1L;

	private DefaultTableModel studentModel;
	private JTable studentTable;
	private JPanel jPanel;
	private JPanel jPanel2;

	public StudentTablePanel() {

		setLayout(new BorderLayout());
		studentModel = new DefaultTableModel();
		studentModel.setColumnIdentifiers(new Object[] { "Nombre", "C�digo", "Im�gen"});
		studentTable = new JTable(studentModel);
		studentTable.setBackground(Color.decode("#E4A900"));
		add(new JScrollPane(studentTable), BorderLayout.CENTER);

	}

	public void fillTable(ArrayList<Student>studentList) {
		studentModel.setRowCount(0);
		for (Student student : studentList) {
			studentModel.addRow(new Object[] { student.getName(), student.getCode(),
					student.getPic() });
		}
		repaint();
	}

	public int getSelectedId() {
		return (int)studentModel.getValueAt(studentTable.getSelectedRow(), 0);
	}
	
	public void changePanelBooking(){ 
		
		jPanel2.setVisible(false);
		jPanel.setVisible(true);
		setVisible(true);
		revalidate();
	}
	
	public void changePanelPerson(){
		jPanel2.setVisible(true);
		jPanel.setVisible(false);
		setVisible(true);
		revalidate();
	}
	

}

