package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controller.Action;

public class StartPanel extends JPanel{
	private static final long serialVersionUID = 1L;
	private JPanel midPanel;
	private JPanel labelsPanel;
	private JPanel topPanel;

	public StartPanel(ActionListener listener) {
		setLayout(new BorderLayout());
		
		TopLogoPanel topLogoPanel = new TopLogoPanel(listener);
//		add(topLogoPanel, BorderLayout.NORTH);
		setBackground(Color.white);
		
		JLabel jLabel = new JLabel("");
			add(jLabel, BorderLayout.WEST);
		
		JLabel jLabel1 = new JLabel("");
			add(jLabel1, BorderLayout.EAST);
		midPanel = new JPanel();
		midPanel.setLayout(new GridLayout(2, 12,0,0));
		midPanel.setBackground(Color.WHITE);
		
		JLabel adminLoginLabel = new JLabel("Inicia sesi�n como estudiante");
		adminLoginLabel.setBackground(Color.pink);
		adminLoginLabel.setBorder(BorderFactory.createEmptyBorder(100,120,0,0));
//		userSessionLabel.setBorderPainted(isFocusable());
		adminLoginLabel.setFocusable(false);
//		userSessionLabel.setBorderPainted(true);
		adminLoginLabel.setFont(new Font("Helvetica", Font.PLAIN, 17));
		adminLoginLabel.setToolTipText("Inicia sesi�n como estudiante");
		adminLoginLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
//		labelsPanel.add(adminLoginLabel);
		midPanel.add(adminLoginLabel);
		
		JLabel userSessionLabel = new JLabel("Inicia sesi�n como administrador");
		userSessionLabel.setBorder(BorderFactory.createEmptyBorder(100,120,0,0));
		userSessionLabel.setBackground(Color.WHITE);
//		userSessionLabel.setBorderPainted(isFocusable());
		userSessionLabel.setAlignmentX(CENTER_ALIGNMENT);
		userSessionLabel.setFocusable(false);
//		userSessionLabel.setBorderPainted(true);
		userSessionLabel.setFont(new Font("Helvetica", Font.PLAIN, 16));
		userSessionLabel.setToolTipText("Inicia sesi�n como administrador");
		userSessionLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
		midPanel.add(userSessionLabel);
//		topPanel.add(labelsPanel, BorderLayout.NORTH);
//		topPanel.add(midPanel);
		
		JButton userLoginBtn = new JButton(new ImageIcon(getClass().getResource("/img/userinit.png")));
		userLoginBtn.setToolTipText("Iniciar sesi�n como estudiante");
		userLoginBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
		userLoginBtn.setBorder(BorderFactory.createEmptyBorder());
		userLoginBtn.setBackground(Color.WHITE);
		userLoginBtn.setFocusable(false);
		userLoginBtn.addActionListener(listener);
		userLoginBtn.setActionCommand(Action.SHOW_STUDENT_PANEL.toString());
		midPanel.add(userLoginBtn);
		
//		labelsPanel.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 30));
		JButton adminLoginBtn = new JButton(new ImageIcon(getClass().getResource("/img/adminImage.png")));
		adminLoginBtn.setToolTipText("Iniciar sesi�n como administrador");
		adminLoginBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
		adminLoginBtn.setBorder(BorderFactory.createEmptyBorder(0,50,50,0));
		adminLoginBtn.setBorder(BorderFactory.createEmptyBorder());
		adminLoginBtn.setBackground(Color.WHITE);
		adminLoginBtn.setFocusable(false);
		adminLoginBtn.addActionListener(listener);
		adminLoginBtn.setActionCommand(Action.SHOW_ADMINISTRATOR_PANEL.toString());
 		midPanel.add(adminLoginBtn);
 		midPanel.setBorder(BorderFactory.createEmptyBorder(0, 150, 180, 276));
// 		add(midPanel, BorderLayout.CENTER);
// 		add(topPanel);
 		add(midPanel, BorderLayout.CENTER);
 		
	}
}
