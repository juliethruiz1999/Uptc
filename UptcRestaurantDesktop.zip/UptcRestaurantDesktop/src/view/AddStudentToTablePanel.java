package view;

import javax.swing.JPanel;

public class AddStudentToTablePanel extends JPanel{

	private static final long serialVersionUID = 1L;

	public AddStudentToTablePanel() {
	}
}
