package view;

import java.awt.BorderLayout;

import javax.swing.JComboBox;
import javax.swing.JPanel;

public class DatePanel extends JPanel{

	private static final long serialVersionUID = 1L;

		String[] month = { "Enero", "Febero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre",
				"Noviembre", "Diciembre" };
		JComboBox<Integer> day;
		JComboBox<String> months;
		JComboBox<Integer> age;

		public DatePanel() {

			JPanel jPanel = new JPanel();
			day = new JComboBox<Integer>();
			months = new JComboBox<String>();
			age = new JComboBox<Integer>();

			for (int i = 1; i < 32; i++) {
				day.addItem(i);
			}
			for (int i = 0; i < 12; i++) {
				months.addItem(month[i]);
			}
			for (int i = 2018; i < 2050; i++) {
				age.addItem(i);
			}
			jPanel.add(day);
			jPanel.add(months);
			jPanel.add(age);

			add(jPanel, BorderLayout.CENTER);
		}

		public int getDay() {
			return (int) day.getSelectedItem();
		}

		public int getMonth() {
			return (int) months.getSelectedIndex() + 1;
		}

		public int getAge() {
			return (int) age.getSelectedItem();
		}
}
