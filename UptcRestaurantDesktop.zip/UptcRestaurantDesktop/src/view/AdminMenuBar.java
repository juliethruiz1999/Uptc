package view;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import controller.Action;

public class AdminMenuBar extends JMenuBar{
	private static final long serialVersionUID = 1L;

	public AdminMenuBar(ActionListener listener) {
		setBackground(Color.WHITE);
		
		JMenu fileItem = new JMenu("Archivo");
		fileItem.setCursor(new Cursor(Cursor.HAND_CURSOR));
		fileItem.setToolTipText("Archivo");
		
		fileItem.setForeground(Color.BLACK);
		setBackground(Color.WHITE);
		JMenuItem itemAddBooking = new JMenuItem("Agregar estudiante a la mesa");
		itemAddBooking.setCursor(new Cursor(Cursor.HAND_CURSOR));
		itemAddBooking.setToolTipText("Agregar usuario a la mesa");
		itemAddBooking.setIcon(new ImageIcon(getClass().getResource("/img/adduser.png")));
		itemAddBooking.setBackground(Color.decode("#E7ECED"));
		itemAddBooking.addActionListener(listener);
		itemAddBooking.setActionCommand(Action.SHOW_ADD_STUDENT_TO_TABLE.toString());
		fileItem.add(itemAddBooking);

		JMenuItem addMenuItem = new JMenuItem("Agregar men�");
		addMenuItem.setIcon(new ImageIcon(getClass().getResource("/img/addMenu.png")));
		addMenuItem.setCursor(new Cursor(Cursor.HAND_CURSOR)); 
		addMenuItem.setBackground(Color.decode("#E7ECED"));
		addMenuItem.setToolTipText("Agregar men�");
		addMenuItem.addActionListener(listener);
		addMenuItem.setActionCommand(Action.SHOW_ADD_MENU_PANEL.toString());
		fileItem.add(addMenuItem);
		
		add(fileItem);
		
		}
}
