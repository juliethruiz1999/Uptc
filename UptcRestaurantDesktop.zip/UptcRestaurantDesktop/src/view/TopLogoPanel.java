package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class TopLogoPanel extends JPanel{

	private static final long serialVersionUID = 1L;
	public TopLogoPanel(ActionListener listener) {

	setLayout(new BorderLayout());
	setBackground(Color.WHITE);

	AdministratorToolBar administratorToolBar = new AdministratorToolBar(listener);
	add(administratorToolBar, BorderLayout.NORTH);
	
	JLabel lblImage = new JLabel(new ImageIcon(getClass().getResource("/img/logo.png")));
	add(lblImage, BorderLayout.CENTER);
	
	}
}