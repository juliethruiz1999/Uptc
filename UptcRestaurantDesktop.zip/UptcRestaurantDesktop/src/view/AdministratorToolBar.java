package view;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JToolBar;

import controller.Action;

public class AdministratorToolBar extends JToolBar{

	private static final long serialVersionUID = 1L;
	
	public AdministratorToolBar(ActionListener listener) {
		setFloatable(false);

		setBackground(Color.decode("#E7ECED"));
		
		
		JButton addUserToTableBtn = new JButton(new ImageIcon(getClass().getResource("/img/usertool.png")));
		addUserToTableBtn.setToolTipText("Agregar estudiante a la mesa");
		addUserToTableBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
		addUserToTableBtn.setBackground(Color.decode("#E7ECED"));
		addUserToTableBtn.setFocusable(false);
		addUserToTableBtn.addActionListener(listener);
		addUserToTableBtn.setBorder(BorderFactory.createEmptyBorder());
		addUserToTableBtn.setActionCommand(Action.ADD_STUDENT_TO_TABLE.toString());
		add(addUserToTableBtn);
		
		JButton addMenuBtn = new JButton(new ImageIcon(getClass().getResource("/img/addmenu.png")));
		addMenuBtn.setToolTipText("Agregar men�");
		addMenuBtn.setBorder(BorderFactory.createEmptyBorder());
		addMenuBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
		addMenuBtn.setBackground(Color.decode("#E7ECED"));
		addMenuBtn.setFocusable(false);
		addMenuBtn.addActionListener(listener);
		addMenuBtn.setActionCommand(Action.ADD_MENU.toString());
		add(addMenuBtn);
		
		JButton deleteBtn = new JButton(new ImageIcon(getClass().getResource("/img/deletetool.png")));
		deleteBtn.setToolTipText("Borrar");
		deleteBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
		deleteBtn.setBorder(BorderFactory.createEmptyBorder());
//		deleteBtn.setBackground(Color.decode("#E7ECED"));
		deleteBtn.setBackground(Color.decode("#E4A900"));
		deleteBtn.setFocusable(false);
		deleteBtn.addActionListener(listener);
		deleteBtn.setActionCommand(Action.DELETE_STUDENT_OF_TABLE.toString());
		deleteBtn.setActionCommand(Action.DELETE_MENU.toString());
		add(deleteBtn);
	}
}
