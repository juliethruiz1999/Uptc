package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import model.Student;

public class StudentWindow extends JPanel implements ActionListener {

//	private JTabbedPane userTab;
	private static final long serialVersionUID = 1L;
	private DefaultTableModel studentModel;
	private JTable studentTable;

	public StudentWindow(ActionListener listener) {

	}

	public void fillTable(ArrayList<Student> studentList) {
		studentModel.setRowCount(0);
		for (Student student : studentList) {
			studentModel.addRow(new Object[] {student.getName(), student.getCode(), student.getImage()});
		}
		repaint();
	}
	
	public String getSelectedId() {
		return studentModel.getValueAt(studentTable.getSelectedRow(), 1).toString();
	}

	@Override
	public void actionPerformed(ActionEvent e) {

	}


}
