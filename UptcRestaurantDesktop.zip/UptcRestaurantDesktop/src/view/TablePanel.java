package view;

import java.awt.GridLayout;

import javax.swing.JPanel;

public class TablePanel extends JPanel{

	public TablePanel() {
		setLayout(new GridLayout(2,2));
	}
}
