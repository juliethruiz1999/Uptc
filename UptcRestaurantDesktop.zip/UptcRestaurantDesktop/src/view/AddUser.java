package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;

import controller.Action;
import model.Student;
import model.StudentManager;

public class AddUser extends JDialog{
	private static final long serialVersionUID = 1L;

	private JTextField txNamePerson;
	private JTextField studentCodeTextField;
	private JPanel jPanel;
	private JPanel panelTxName;
	private JLabel jLabelError;
	private FileNameExtensionFilter filter;
	private JPanel jPanelError;
	private JLabel jAdvertence;
	private ImageIcon icon;
	JLabel pic;

	public AddUser(JFrame main, ActionListener listener) {
		super(main);
		
		setSize(380, 480);
		setModal(true);
		setTitle("Agregar estudiante");
		panelTxName = new JPanel();
		panelTxName.setBackground(Color.WHITE);
		panelTxName.setLayout(new BorderLayout());
		
		setLayout(new BorderLayout());
		pic = new JLabel(new ImageIcon(getClass().getResource("/img/userimage.png")));
		pic.setAlignmentX(15);
		pic.setSize(125, 175);

		filter = new FileNameExtensionFilter("Archivo de Imagen", "jpg");

		jPanel = new JPanel();
		jPanel.setBackground(Color.decode("#345678"));
//		jPanel.setLayout(new GridLayout(10, 1,2,2));
		jPanel.setLayout(new BorderLayout());
		
		JPanel imagePanel = new JPanel();
		imagePanel.setLayout(new GridLayout(2, 1,10,10));
		imagePanel.setBackground(Color.WHITE);
		
		JPanel searchImage = new JPanel();
		searchImage.setLayout(new GridLayout(4, 1));
		searchImage.setBackground(Color.WHITE);
		searchImage.setBorder(BorderFactory.createEmptyBorder(0, 90, 0, 90));

		txNamePerson = new JTextField("                ");
		txNamePerson.setBorder(BorderFactory.createTitledBorder("Nombre:"));
//		txNamePerson.setBorder(BorderFactory.createEmptyBorder(top, left, bottom, right));
		txNamePerson.setLayout(new FlowLayout());
		panelTxName.add(txNamePerson, BorderLayout.NORTH);
		
		txNamePerson = new JTextField("                ");
		txNamePerson.setBorder(BorderFactory.createTitledBorder("C�digo:"));
//		txNamePerson.setBorder(BorderFactory.createEmptyBorder(top, left, bottom, right));
		txNamePerson.setLayout(new FlowLayout());
		panelTxName.add(txNamePerson, BorderLayout.CENTER);

		
		jPanel.add(panelTxName, BorderLayout.NORTH);

		imagePanel.add(pic);
		jPanel.setBackground(Color.WHITE);
		JButton buttonCargar = new JButton("Cargar imagen");
		buttonCargar.setBorderPainted(isFocusable());
		buttonCargar.setBackground(Color.WHITE);
		buttonCargar.setFocusable(false);
		buttonCargar.setBorderPainted(true);
		buttonCargar.setFont(new Font("Helvetica", Font.PLAIN, 16));
		buttonCargar.setToolTipText("Cargar imagen");
		buttonCargar.setCursor(new Cursor(Cursor.HAND_CURSOR));
		buttonCargar.addActionListener(listener);
		buttonCargar.setActionCommand(Action.CHARGE_IMAGE.toString());
		searchImage.add(buttonCargar);
		jPanel.add(imagePanel, BorderLayout.CENTER);
		
		imagePanel.add(searchImage);
		
		
		JPanel jPanel2 = new JPanel();
		jPanel2.setLayout(new FlowLayout());
		JButton btnAdd = new JButton("Agregar estudiante");
		btnAdd.addActionListener(listener);
		btnAdd.setBackground(Color.WHITE);
		btnAdd.setFont(new Font("Helvetica", Font.PLAIN, 15));
		btnAdd.setToolTipText("Agregar estudiante");
		btnAdd.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnAdd.setActionCommand(Action.ADD_STUDENT.toString());

		jPanel2.add(btnAdd);
		jPanel2.setBackground(Color.WHITE);
//		jPanel.add(buttonCargar, BorderLayout.CENTER);
		JButton btnBack = new JButton("Atras");
		btnBack.addActionListener(listener);
		btnBack.setBackground(Color.WHITE);
		btnBack.setBorderPainted(true);
		btnBack.setFont(new Font("Helvetica", Font.PLAIN, 15));
		btnBack.setActionCommand(Action.BACK.toString());
		btnBack.setToolTipText("Atras");
		btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
		jPanel2.add(btnBack);

		jPanel.add(jPanel2, BorderLayout.PAGE_END);
		

		add(jPanel);
	}

	public Student createStudent() {
		return StudentManager.createStudent(txNamePerson.getText(), studentCodeTextField.getText(), icon.getDescription());
	}

	public void chargeImage() {
		String fill ="";
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setFileFilter(filter);
		int option = fileChooser.showOpenDialog(this);
		if (option == JFileChooser.APPROVE_OPTION) {
			fill = fileChooser.getSelectedFile().getPath();
			pic.setIcon(new ImageIcon(fill));
			icon = new ImageIcon(fill);
			Image img = icon.getImage();
			Image newImg = img.getScaledInstance(155, 175, Image.SCALE_SMOOTH);
			ImageIcon newIcon = new ImageIcon(newImg);
			pic.setText("");
			pic.setIcon(newIcon);
			pic.setSize(155, 175);
		}
	}

	public void clean() {
		txNamePerson.setText("                ");
		pic.setIcon(new ImageIcon(getClass().getResource("/img/userimage.png")));
	}

	public void showError() {
		jPanelError.setLayout(new BorderLayout());
		jLabelError.setText("Caracteres inv�lidos");
		jPanelError.add(jLabelError, BorderLayout.CENTER);
		jPanelError.add(jAdvertence, BorderLayout.WEST);
		panelTxName.add(jPanelError);
		setVisible(true);
	}

}
