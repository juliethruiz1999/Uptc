package view;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;

import controller.Action;

public class AdministratorLeftPanel extends JPanel{

	private static final long serialVersionUID = 1L;

	public AdministratorLeftPanel(ActionListener listener) {
	
		setLayout(new GridLayout(12,1,20,0));
		setBackground(Color.WHITE);

		JButton addStudentButton = new JButton("Agregar Estudiante a la mesa");
		addStudentButton.setBackground(Color.decode("#E7ECED"));
		addStudentButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
		addStudentButton.addActionListener(listener);
		addStudentButton.setActionCommand(Action.ADD_STUDENT_TO_TABLE.toString());
		addStudentButton.setToolTipText("Agregar Estudiante a la mesa");
		addStudentButton.setFont(new Font("Helvetica", Font.PLAIN, 17));
		addStudentButton.setFocusable(false);
		add(addStudentButton);
		

		JButton addMenuButton = new JButton("Agregar Men�");
		addMenuButton.setBackground(Color.decode("#E7ECED"));
		addMenuButton.setToolTipText("Agregar Men�");
		addMenuButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
		addMenuButton.setFont(new Font("Helvetica", Font.PLAIN, 17));
		addMenuButton.setBorder(BorderFactory.createMatteBorder(0, 1, 1, 1, Color.BLACK));
		addMenuButton.setFocusable(false);
		addMenuButton.addActionListener(listener);
		addMenuButton.setActionCommand(Action.ADD_MENU.toString());
		add(addMenuButton);
		
		JButton menuListButton = new JButton("Mostrar men�s");
		menuListButton.setBackground(Color.decode("#E7ECED"));
		menuListButton.setToolTipText("Mostrar men�s");
		menuListButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
		menuListButton.addActionListener(listener);
		menuListButton.setActionCommand(Action.SHOW_MENU.toString());
		menuListButton.setFocusable(false);
		menuListButton.setFont(new Font("Helvetica", Font.PLAIN, 17));
		menuListButton.setBorder(BorderFactory.createMatteBorder(0, 1, 1, 1, Color.BLACK));
		add(menuListButton);
//		menuListButton
		JButton topMenuListButton = new JButton("Mostrar top 5 de men�s");
		topMenuListButton.setBackground(Color.decode("#E7ECED"));
		topMenuListButton.setToolTipText("Mostrar top 5 de men�s");
		topMenuListButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
		topMenuListButton.setFont(new Font("Helvetica", Font.PLAIN, 17));
		topMenuListButton.addActionListener(listener);
		topMenuListButton.setActionCommand(Action.SHOW_TOP_LIST.toString());
		topMenuListButton.setBorder(BorderFactory.createMatteBorder(0, 1, 1, 1, Color.BLACK));
		topMenuListButton.setFocusable(false);
		add(topMenuListButton);
		
		JButton totalPercentBtn = new JButton("Estudiantes que ingresaron al restaurante");
		totalPercentBtn.setBackground(Color.decode("#E7ECED"));
		totalPercentBtn.setToolTipText("Estudiantes que ingresaron al restaurante");
		totalPercentBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
		totalPercentBtn.setFont(new Font("Helvetica", Font.PLAIN, 17));
		totalPercentBtn.addActionListener(listener);
		totalPercentBtn.setActionCommand(Action.SHOW_TOTAL_STUDENTS_PERCENT.toString());
		totalPercentBtn.setBorder(BorderFactory.createMatteBorder(0, 1, 1, 1, Color.BLACK));
		totalPercentBtn.setFocusable(false);
		add(totalPercentBtn);
		
		JButton percentByCareerBtn = new JButton("Estudiantes que ingresaron al restaurante por carrera");
		percentByCareerBtn.setBackground(Color.decode("#E7ECED"));
		percentByCareerBtn.setToolTipText("Estudiantes que ingresaron al restaurante por carrera");
		percentByCareerBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
		percentByCareerBtn.setFont(new Font("Helvetica", Font.PLAIN, 17));
		percentByCareerBtn.addActionListener(listener);
		percentByCareerBtn.setActionCommand(Action.SHOW_STUDENTS_PERCENT_BY_CAREER.toString());
		percentByCareerBtn.setBorder(BorderFactory.createMatteBorder(0, 1, 1, 1, Color.BLACK));
		percentByCareerBtn.setFocusable(false);
		add(percentByCareerBtn);
//
//		TablesNumberPanel tablesNumberPanel = new TablesNumberPanel(listener);
//		add(tablesNumberPanel);


	}
}
