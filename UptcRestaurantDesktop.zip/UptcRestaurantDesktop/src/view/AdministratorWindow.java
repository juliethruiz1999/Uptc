package view;


import java.awt.BorderLayout;
import java.awt.event.ActionListener;

import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JPanel;

public class AdministratorWindow extends JPanel{

	private static final long serialVersionUID = 1L;

	public AdministratorWindow(ActionListener listener) {
		setLayout(new BorderLayout());
		
		AdministratorToolBar administratorToolBar = new AdministratorToolBar(listener);
		add(administratorToolBar);
		
		AdminMenuBar adminMenuBar = new AdminMenuBar(listener);
		add(adminMenuBar);
		
		AdministratorLeftPanel administratorLeftPanel= new AdministratorLeftPanel(listener);
		add(administratorLeftPanel, BorderLayout.WEST);
		
		
		
	}
}
