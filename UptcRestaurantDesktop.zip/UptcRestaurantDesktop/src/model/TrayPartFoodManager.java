package model;

import java.util.ArrayList;

public class TrayPartFoodManager {
	
	private ArrayList<TrayPartFood> trayPartFoodList;
	
	public TrayPartFoodManager() {
		trayPartFoodList = new ArrayList<>();
	}


	public static TrayPartFood createTrayPartFood(String name, TrayParts trayParts){
		return new TrayPartFood(trayParts, name);
	}
	
	public void addTrayPartFood(TrayPartFood trayPartFood){
		trayPartFoodList.add(trayPartFood);
	}
	
	
	public ArrayList<TrayPartFood> getTrayPartFoodList() {
		return trayPartFoodList;
	}
}
