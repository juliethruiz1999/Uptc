package model;

public class Soup {

}
