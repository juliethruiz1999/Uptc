package model;

import java.util.ArrayList;

public class Restaurant {
	
	private String name;
	private Administrator administrator;
	private ArrayList<Floor> floorList;

	public Restaurant(String name) {
		this.name = name;
	}

	public Administrator getAdministrator() {
		return administrator;
	}

	public void setAdministrator(Administrator administrator) {
		this.administrator = administrator;
	}

	public ArrayList<Floor> getFloorList() {
		return floorList;
	}

	public String getName() {
		return name;
	}
	
//	public ArrayList<Menu> getTopMenuList(){
//	
//	}
}
	