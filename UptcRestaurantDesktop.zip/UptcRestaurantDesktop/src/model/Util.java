package model;

import java.text.SimpleDateFormat;

public class Util {
	public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");
}
