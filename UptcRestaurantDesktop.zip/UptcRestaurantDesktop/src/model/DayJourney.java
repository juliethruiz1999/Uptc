package model;

public enum DayJourney {
	LUNCH, DINNER;
}
