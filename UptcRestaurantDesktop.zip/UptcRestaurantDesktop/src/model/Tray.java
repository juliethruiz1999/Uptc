package model;

import java.util.ArrayList;

public class Tray {
	
	private ArrayList<TrayPartFood> trayPartFood;
	
	public Tray(ArrayList<TrayPartFood> trayPartFood) {
		this.trayPartFood = new ArrayList<>();
		this.trayPartFood = trayPartFood;
	
	}

	public ArrayList<TrayPartFood> getTrayPartFood() {
		return trayPartFood;
	}
}
