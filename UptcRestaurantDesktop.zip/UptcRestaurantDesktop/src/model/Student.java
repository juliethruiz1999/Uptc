package model;

import java.util.ArrayList;

public class Student {

	private String name;
	private String code;
	private String pic;
	private ArrayList<Menu> likedMenus;
	
	public Student(String name, String code, String pic){
		this.name = name;
		this.code = code;
		this.pic = pic;
	}
	
	public String getPic() {
		return pic;
	}

	public void setPic(String pic) {
		this.pic = pic;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public Object getImage() {
		return null;
	}

	public String getName() {
		return name;
	}
	
	public void addMenu(Menu menu){
		  likedMenus.add(menu);
	}

	@Override
	public String toString() {
		return "Student [name=" + name + ", pic=" + pic + "]";
	}

	public ArrayList<Menu> getLikedMenus(){
		return likedMenus;
	}

	public String getCode() {
		return code;
	}

}
