package model;

import java.util.ArrayList;

public class TrayManager {
	
		private ArrayList<Tray> listTray;

		public TrayManager() {
			listTray = new ArrayList<>();
		}

		public static Tray createTray(ArrayList<TrayPartFood> listPartFoods) {
			return new Tray(listPartFoods);
		}

		public void addTray(Tray tray) {
			listTray.add(tray);
		}

		public void deleteTray(Tray tray) {
			listTray.remove(tray);
		}

}
