package model;

public class TrayPartFood {

	private TrayParts trayParts;
	private String name;
	
	public TrayPartFood(TrayParts trayParts, String name) {
		this.trayParts = trayParts;
		this.name = name;
	}

	public TrayParts getTrayParts() {
		return trayParts;
	}
	public void setTrayParts(TrayParts trayParts) {
		this.trayParts = trayParts;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
