package model;

import java.util.ArrayList;

public class Table {
	
	private ArrayList<Student> userList;
	private int posts;
	
	public Table() {
		userList = new ArrayList<>();
		posts = 4;
	}

	public ArrayList<Student> getUserList() {
		return userList;
	}

	public void setUserList(ArrayList<Student> userList) {
		this.userList = userList;
	}

	public int getPosts() {
		return posts;
	}

	public void setPosts(int posts) {
		this.posts = posts;
	}
	
	public void addUserToTable(Student user){
		userList.add(user);
	}

	public void deleteUserOfTable(Student user){
		userList.remove(user);
	}
}
