package model;

import java.util.ArrayList;

public class StudentManager {
	private ArrayList<Student> studentList;
	
	public StudentManager() {
		studentList = new ArrayList<>();
	}
	
	public static Student createStudent(String name, String code, String pic){
		return new Student(name, code, pic);
	}
	
	public void addStudent(Student student) {
		studentList.add(student);
	}
	
	public void deleteStudent(String code) {
		for (Student student : studentList) {
			if(student.getCode() == code){
				studentList.remove(student);
				break;
			}
		}
	}
	
	public ArrayList<Student> getUserList() {
		return studentList;
	}
	
}
