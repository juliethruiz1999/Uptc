package model;

public enum TrayParts {
	SOUP, JUICE, VEGETABLE, FRUIT, PLATE;
}
