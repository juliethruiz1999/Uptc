package model;

public class Food {

}
