package model;

import java.util.ArrayList;

public class TableManager {
	
//	private ArrayList<>
}
