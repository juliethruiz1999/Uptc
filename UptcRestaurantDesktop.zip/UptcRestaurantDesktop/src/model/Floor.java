package model;

import java.util.ArrayList;

public class Floor {

	private ArrayList<Table> tableList;
	private int tablesNumber;
	
	public Floor(Table table) {
		tablesNumber = 20;
		tableList = new ArrayList<>();
		for (int i = 0; i < tablesNumber; i++) {
			tableList.add(table);
		}
	}

	public ArrayList<Table> getTableList() {
		return tableList;
	}

}
