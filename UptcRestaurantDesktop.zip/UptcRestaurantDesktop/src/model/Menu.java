package model;

import java.util.ArrayList;

public class Menu {

	private Tray tray;
	private int likes;

	public Menu(Tray tray) {
		this.tray = tray;
	}

	public Tray getTray() {
		return tray;
	}

	public int getLikes() {
		return likes;
	}
}
