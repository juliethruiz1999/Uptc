package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MenuManager {

	private ArrayList<Menu> menuList;

	public MenuManager() {
		menuList = new ArrayList<>();
	}

	public static Menu createMenu(Tray tray) {
		return new Menu(tray);
	}

	public void addMenu(Menu menu) {
		menuList.add(menu);
	}

	public void deleteMenu(Menu menu) {
		menuList.remove(menu);
	}

	public void orderByLikes(){
	
		Collections.sort(menuList, new Comparator<Menu>() {

			@Override
			public int compare(Menu p1, Menu p2) {
				// Aqui esta el truco, ahora comparamos p2 con p1 y no al reves como antes
				return new Integer(p2.getLikes()).compareTo(new Integer(p1.getLikes()));
			}

		});
	}

}
