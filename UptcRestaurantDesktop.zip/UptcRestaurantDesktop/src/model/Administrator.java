package model;

public class Administrator {
	private String name;
	private String password;
	private TrayManager trayManager;
	private TrayPartFoodManager trayPartFoodManager;
	private MenuManager menuManager;
	
	public Administrator(String name, String password) {
		this.name = name;
		this.password = password;
		trayManager = new TrayManager();
		trayPartFoodManager = new TrayPartFoodManager();
		menuManager = new MenuManager();
	}

	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return "Administrator [name=" + name + ", password=" + password + "]";
	}

	public String getPassword() {
		return password;
	}
	
	public void setTrayPartFoodManager(TrayPartFoodManager trayPartFoodManager) {
		this.trayPartFoodManager = trayPartFoodManager;
	}

	public MenuManager getMenuManager() {
		return menuManager;
	}

	public void setMenuManager(MenuManager menuManager) {
		this.menuManager = menuManager;
	}

	public TrayManager getTrayManager() {
		return trayManager;
	}
	
	public TrayPartFoodManager getTrayPartFoodManager() {
		return trayPartFoodManager;
	}



}
