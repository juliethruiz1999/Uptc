package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.GregorianCalendar;

import javax.swing.ImageIcon;

import model.Administrator;
import model.MenuManager;
import model.Restaurant;
import model.Student;
import model.StudentManager;
import sun.awt.RepaintArea;
import view.AddStudentJDialog;
import view.AddUser;
import view.AdministratorWindow;
import view.MainWindow;
import view.StudentTablePanel;
import view.StudentWindow;


public class Control implements ActionListener{

	private StudentManager studentManager;
	private MenuManager menuManager;
	private StudentWindow studentWindow;
	private AdministratorWindow administratorWindow;
	private AddStudentJDialog addStudentJDialog;
	private MainWindow mainWindow;
	private Administrator administrator;
	private Restaurant restaurant;
	
	public Control() {

		studentManager = new StudentManager();
		studentWindow = new StudentWindow(this);
		addStudentJDialog = new AddStudentJDialog(mainWindow, this);
		mainWindow = new MainWindow(this);
		mainWindow.showStartPanel();
		administratorWindow = new AdministratorWindow(this);
		restaurant = new Restaurant("");
		mainWindow.setVisible(true);
//		mainWindow.getStudentWindow().fillTable(studentManager.getUserList());
		
//		administrator = new Administrator("Juan", "54");
//		restaurant = new Restaurant("Upt");
//		studentManager.addStudent(studentManager.createStudent("Camilo", "201611937", new ImageIcon().getClass().getResource("/img/cutlery.png").toString()));
//		mainWindow.getStudentTablePanel().fillTable(studentManager.getUserList());
//		mainWindow.setVisible(true);
		addStudentJDialog.refreshPanelRegistry(studentManager.getUserList());;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		switch (Action.valueOf(e.getActionCommand())) {
		case SHOW_START_PANEL:
			showStartPanel();
		case SHOW_STUDENT_PANEL:
			showStudentPanel();
			break;
		case SHOW_ADMINISTRATOR_PANEL:
			showAdministratorPanel();
		case ADD_STUDENT:
			addStudent();
			break;
		case DELETE_STUDENT:
			deleteStudent();
			break;
		case ADD_STUDENT_TO_TABLE:
			addStudentToTable();
			break;
		case DELETE_STUDENT_OF_TABLE:
			deleteStudentOfTable();
		}
	}
	
	private void showStartPanel() {
//		mainWindow.c
		mainWindow.changeStartPanel();
//		mainWindow.update();
	}

	private void deleteStudentOfTable() {
		
	}

	private void addStudentToTable() {
		
	}

	private void showAdministratorPanel() {
		mainWindow.changePanelAdmin();
//		mainWindow.update();
		
	}

//	private void showUserPanel() {
////		mainWindow.showStudentPanel();
//		mainWindow.changePanelAdmin();
//		mainWindow.update();
//		
//
//	}		
	

	private void showStudentTable() {
		mainWindow.getStudentTablePanel().changePanelPerson();
	}


//	private void showChangeTables() {
//		tablesNumberPanel.setVisible(true);
//	}

	
//	private void changeTables() {
//		restaurant.setTables(mainWindow.getTablesNumber().getDay());
//		showTables();
//	}

//	private void showTables() {
//		mainWindow.getTablePanel().showTables(restaurant.listTables(bookingService.getBookingList(), mainWindow.getTablePanel().getFecha()),
//				restaurant.getTables());
//		mainWindow.setVisible(true);
//	}
//	
//		addUser.dispose();
//	}

	private void chargeImage() {
		addStudentJDialog.chargeImage();
	}

//	private void showAddUser() {
//		addUser.setVisible(true);
//	}

	private void deleteStudent() {
		studentManager.deleteStudent(studentWindow.getSelectedId());
		studentWindow.fillTable(studentManager.getUserList());
	}
	

	private void addStudent() {
		Student student = addStudentJDialog.createStudent();
		studentManager.addStudent(student);
		addStudentJDialog.dispose();
		addStudentJDialog.clean();
		addStudentJDialog.refreshPanelRegistry(studentManager.getUserList());
		mainWindow.getStudentTablePanel().fillTable(studentManager.getUserList());
	}


	private void showStudentPanel() {
//		studentWindow.setVisible(true);
		mainWindow.changeStudentPanel();
		mainWindow.update();
	}

//	private void showMenuPanel() {
//		addBooking.setVisible(true);
//	}
//
//	private void addMenu() {
//	
//		Booking booking = addBooking.createBooking();
//		Menu menu = addMenu
//		bookingService.addBooking(booking);
//		System.out.println(bookingService.getBookingList());
//		mainWindow.getTableListPanel().fillTable(bookingService.getBookingList());
//		addBooking.dispose();
//	}	
}
